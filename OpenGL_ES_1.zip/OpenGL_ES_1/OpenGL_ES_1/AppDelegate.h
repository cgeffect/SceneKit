//
//  AppDelegate.h
//  OpenGL_ES_1
//
//  Created by hr on 2017/7/4.
//  Copyright © 2017年 Jason. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

