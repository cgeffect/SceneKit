//
//  OpenGLKViewController.h
//  OpenGL_ES_1
//
//  Created by hr on 2017/7/4.
//  Copyright © 2017年 Jason. All rights reserved.
//

#import <GLKit/GLKit.h>

@interface OpenGLKViewController : GLKViewController
@property (strong, nonatomic) EAGLContext *context;
@property (assign, nonatomic) GLuint shaderProgram;
@end
