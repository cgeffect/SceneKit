//
//  OpenGLKViewController.m
//  OpenGL_ES_1
//
//  Created by hr on 2017/7/4.
//  Copyright © 2017年 Jason. All rights reserved.
//

#import "OpenGLKViewController.h"

@implementation OpenGLKViewController
    
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupContext];
    
}
- (void)setupContext {
    // 使用OpenGL ES2, ES2之后都采用Shader来管理渲染管线
    self.context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    
    GLKView *view = (GLKView *)self.view;
    view.context = self.context;
    [EAGLContext setCurrentContext:self.context];
    
//    glClear(GL_COLOR_BUFFER_BIT);

//    glClearColor(1, 0.2, 0.2, 1);

}

- (void)glkView:(GLKView *)view drawInRect:(CGRect)rect {
    // 清空之前的绘制
    glClear(GL_COLOR_BUFFER_BIT);
    //绘制颜色
    glClearColor(1, 0.0, 0.0, 1);
}
@end
