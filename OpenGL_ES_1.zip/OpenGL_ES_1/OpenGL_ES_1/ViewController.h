//
//  ViewController.h
//  OpenGL_ES_1
//
//  Created by hr on 2017/7/4.
//  Copyright © 2017年 Jason. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>

@interface ViewController : GLKViewController
{
    GLuint vertexBufferID; //顶点数据缓存的标识符
}
//GLKBaseEffect是GLKit提供的一个内建类, GLKBaseEffect的存在是为了简化很多OpenGL ES 的常用操作, GLKBaseEffect隐藏了多个iOS版本对OpenGL ES支持的差异,
@property (strong, nonatomic) GLKBaseEffect *baseEffect;
@end

