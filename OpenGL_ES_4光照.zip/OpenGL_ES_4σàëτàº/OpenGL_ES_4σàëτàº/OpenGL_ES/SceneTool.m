//
//  AppDelegate.m
//  OpenGL_ES_4光照
//
//  Created by hr on 2017/7/7.
//  Copyright © 2017年 Jason. All rights reserved.
//
#import "SceneTool.h"

#pragma mark - Triangle manipulation


/**
 *  创建一个三角形
 *
 *  @param vertexA 顶点A
 *  @param vertexB 顶点B
 *  @param vertexC 顶点C
 *
 *  @return 三角形
 */
SceneTriangle SceneTriangleMake(const SceneVertex vertexA, SceneVertex vertexB,const SceneVertex vertexC)
{
    SceneTriangle   result;
    
    result.vertices[0] = vertexA;
    result.vertices[1] = vertexB;
    result.vertices[2] = vertexC;
    
    return result;
}


/**
 *  以点0为出发点，通过叉积计算平面法向量
 *
 *  @param triangle 三角形
 *
 *  @return 平面法向量
 */
GLKVector3 SceneTriangleFaceNormal(const SceneTriangle triangle)
{
    GLKVector3 vectorA = GLKVector3Subtract(
                                            triangle.vertices[1].position,
                                            triangle.vertices[0].position);
    GLKVector3 vectorB = GLKVector3Subtract(
                                            triangle.vertices[2].position,
                                            triangle.vertices[0].position);
    
    return SceneVector3UnitNormal(
                                  vectorA,
                                  vectorB);
}


/**
 *  计算三角形平面法向量，更新每个点的平面法向量
 *
 *  @param someTriangles 三角形数组
 *
 */
void SceneTrianglesUpdateFaceNormals(SceneTriangle someTriangles[NUM_FACES])
{
    int i;
    
    for (i=0; i<NUM_FACES; i++)
    {
        GLKVector3 faceNormal = SceneTriangleFaceNormal(
                                                        someTriangles[i]);
        someTriangles[i].vertices[0].normal = faceNormal;
        someTriangles[i].vertices[1].normal = faceNormal;
        someTriangles[i].vertices[2].normal = faceNormal;
    }
}


#pragma mark - Utility GLKVector3 functions
/**
 *  通过向量A和向量B的叉积求出平面法向量，单元化后返回
 *
 *  @param vectorA 向量A
 *  @param vectorB 向量B
 *
 *  @return 单元平面法向量
 */
GLKVector3 SceneVector3UnitNormal(const GLKVector3 vectorA, GLKVector3 vectorB)
{
    return GLKVector3Normalize(GLKVector3CrossProduct(vectorA, vectorB));
}


