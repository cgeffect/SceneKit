//
//  ViewController.h
//  OpenGL_ES_4光照
//
//  Created by hr on 2017/7/7.
//  Copyright © 2017年 Jason. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GLKit/GLKit.h>
#import "AGLKVertexAttribArrayBuffer.h"
#import "AGLKContext.h"
#import "SceneTool.h"

@interface ViewController : GLKViewController
@property (strong, nonatomic) GLKBaseEffect*baseEffect;
@property (strong, nonatomic) AGLKVertexAttribArrayBuffer *vertexBuffer;
@property (nonatomic) GLfloat centerVertexHeight;
@end

