//
//  GameViewController.swift
//  MarbleMaze
//
//  Created by hr on 2017/7/24.
//  Copyright © 2017年 Jason. All rights reserved.
//

import UIKit
import SceneKit
class GameViewController: UIViewController {
    
    var scnView:SCNView!
    var scnScene:SCNScene!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 1
        setupScene()
    }
    // 2
    func setupScene() {
        scnView = self.view as! SCNView
        scnView.delegate = self
        scnView.allowsCameraControl = true
        scnView.showsStatistics = true
        
        // 1
        scnScene = SCNScene(named: "art.scnassets/game.scn")
        // 2
        scnView.scene = scnScene
    }
}
// 3
extension GameViewController: SCNSceneRendererDelegate {
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time:
        TimeInterval) {
    }
}
