//
//  GameViewController.swift
//  SceneEditor
//
//  Created by hr on 2017/7/22.
//  Copyright © 2017年 Jason. All rights reserved.
//

import UIKit
import SceneKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // create a new scene
        let scene = SCNScene(named: "art.scnassets/game.scn")!
        
        
        // retrieve the SCNView
        let scnView = self.view as! SCNView
        
        // set the scene to the view
        scnView.scene = scene
        
    }
}
